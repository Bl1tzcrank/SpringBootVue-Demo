<template>
    <el-container>
        <el-header>
            <div>
                Library Management System
            </div>
        </el-header>
        <el-main>
            <el-descriptions title="`" direction="vertical" :column="2"
                             border>
                <el-descriptions-item label="Username" align="center">{{user.username}}</el-descriptions-item>
                <el-descriptions-item label="Nickname" align="center">{{user.nickName}}</el-descriptions-item>
                <el-descriptions-item label="Age" align="center">{{user.age}}</el-descriptions-item>
                <el-descriptions-item label="Sex" align="center">{{user.sex}}</el-descriptions-item>
                <el-descriptions-item label="Address" align="center">{{user.address}}
                </el-descriptions-item>
                <el-descriptions-item>
                </el-descriptions-item>
            </el-descriptions>
        </el-main>
    </el-container>
</template>

<style>
    .el-header {
        font-size: 40px;
        text-align: center;
        line-height: 100px;
    }

    .el-main {

    }
</style>
<script>
    export default {
        name: "Index",
        data() {
            return {
                user: {},
                path: this.$route.path
            }
        },
        created() {
            let userStr = sessionStorage.getItem("user") || "{}"
            this.user = JSON.parse(userStr)
            console.log(userStr)
        }
    }
</script>