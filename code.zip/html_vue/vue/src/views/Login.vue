<template>
    <div style="width: 100%; height: 100vh; background-color: darkslateblue; overflow: hidden">
        <div style="width: 400px; margin: 100px auto">
            <div style="color: #cccccc; font-size: 50px; text-align: center; padding: 30px 0">Welcome!</div>
            <el-form ref="form" :model="form" size="normal" :rules="rules">
                <el-form-item prop="username">
                    <el-input v-model="form.username" prefix-icon="el-icon-user-solid"
                              placeholder="Enter the Username"></el-input>
                </el-form-item>
                <el-form-item prop="password">
                    <el-input v-model="form.password" prefix-icon="el-icon-lock" placeholder="Enter your Password"
                              show-password></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button style="width: 100%" type="primary" @click="login">LOGIN</el-button>
                </el-form-item>
                <el-form-item>
                    <el-button style="width: 100%" type="primary" @click="register">REGISTER</el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>

<script>
    import request from "@/utils/request";

    export default {
        name: "Login",
        data() {
            return {
                form: {},
                rules: {
                    username: [
                        {required: true, message: 'Please Enter Your Username', trigger: 'blur'}
                    ],
                    password: [
                        {required: true, message: 'Please Enter Your Password', trigger: 'blur'}
                    ]
                }
            }
        },
        methods: {
            login(form) {
                request.post("api/user/login", this.form).then(res => {
                    if (res.code === '0') {
                        this.$message({
                            type: "success",
                            message: "LOGIN SUCCESS!"
                        })
                        console.log(res.data)
                        sessionStorage.setItem("user", JSON.stringify(res.data)) //storage the login info cache
                        this.$router.push("/") //Jump to the Home Page
                    } else {
                        this.$message({
                            type: "error",
                            message: res.msg
                        })
                    }
                })
            },
            register() {
                this.$router.push("/register")
            }
        }
    }
</script>

<style scoped>
</style>