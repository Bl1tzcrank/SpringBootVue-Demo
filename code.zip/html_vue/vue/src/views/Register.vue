<template>
    <div style="width: 100%; height: 100vh; background-color: darkslateblue; overflow: hidden">
        <div style="width: 400px; margin: 100px auto">
            <div style="color: #cccccc; font-size: 50px; text-align: center; padding: 30px 0">New User</div>
            <el-form ref="form" :model="form" size="normal" :rules="rules">
                <el-form-item prop="username">
                    <!--???the function of the prop???-->
                    <el-input v-model="form.username" prefix-icon="el-icon-user-solid"
                              placeholder="Enter the Username"></el-input>
                </el-form-item>
                <el-form-item prop="password">
                    <el-input v-model="form.password" prefix-icon="el-icon-lock" placeholder="Enter the Password"
                              show-password></el-input>
                </el-form-item>
                <el-form-item prop="confirm">
                    <el-input v-model="form.confirm" prefix-icon="el-icon-lock" placeholder="Confirm your Password"
                              show-password></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button style="width: 100%" type="primary" @click="register">REGISTER</el-button>
                </el-form-item>
                <el-form-item>
                    <el-button style="width: 100%" type="primary" @click="return">TO LOGIN</el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>
<!--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Add form verify tomorrow-->
<script>
    import request from "@/utils/request";

    export default {
        name: "Register",
        data() {
            return {
                form: {},
                rules: {
                    username: [
                        {required: true, message: 'Please Enter Your Username', trigger: 'blur'}
                    ],
                    password: [
                        {required: true, message: 'Please Enter Your Password', trigger: 'blur'}
                    ],
                    confirm: [
                        {required: true, message: 'Please Confirm Your Password', trigger: 'blur'}
                    ]
                }
            }
        },
        methods: {
            register() {
                request.post("api/user/register", this.form).then(res => {
                    if (res.code === '0') {
                        this.$message({
                            type: "success",
                            message: "Register SUCCESS!"
                        })
                        this.$router.push("/login") //Jump to the Login Page
                    } else {
                        this.$message({
                            type: "error",
                            message: res.msg
                        })
                    }
                })
            },
            return() {
                this.$router.push("/login")
            }
        }
    }
</script>

<style scoped>
</style>