<template>
    <div style="padding: 10px;">
        <!--Function-->
        <div style="margin: 10px">
            <el-button type="primary" size="small" @click="add">NEW</el-button>
            <el-button type="primary" size="small">IMPORT</el-button>
            <el-button type="primary" size="small">EXPORT</el-button>
        </div>
        <!--Search-->
        <div style="margin: 10px">
            <el-input v-model="search" placeholder="Please Enter Content" style="width: 20%" size="small"></el-input>
            <el-button style="margin-left: 10px" type="primary" size="small" @click="load">SEARCH</el-button>
        </div>
        <el-table
                :data="tableData"
                border
                style="width: 100%">
            <el-table-column
                    prop="id"
                    label="ID"
                    sortable>
            </el-table-column>
            <el-table-column
                    prop="username"
                    label="UserName">
            </el-table-column>
            <el-table-column
                    prop="nickName"
                    label="NickName">
            </el-table-column>
            <el-table-column
                    prop="age"
                    label="Age">
            </el-table-column>
            <el-table-column
                    prop="sex"
                    label="Sex">
            </el-table-column>
            <el-table-column
                    prop="address"
                    label="Address">
            </el-table-column>
            <el-table-column
                    label="Authority">
                <template #default="scope">
                    <span v-if="scope.row.role === 1">Administrator</span>
                    <span v-if="scope.row.role === 2">User</span>
                </template>
            </el-table-column>
            <el-table-column
                    fixed="right"
                    label="Function">
                <template #default="scope">
                    <el-button @click="handleEdit(scope.row)" type="text">Edit</el-button>
                    <el-popconfirm title="Still Want to Delete?" @confirm="handleDelete(scope.row.id)">
                        <template #reference>
                            <el-button type="text">Delete</el-button>
                        </template>
                    </el-popconfirm>
                </template>
            </el-table-column>
        </el-table>
        <div>

            <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="currentPage"
                    :page-sizes="[5,10,20]"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total">
            </el-pagination>

            <el-dialog
                    title="Enter Employee Information"
                    v-model="dialogVisible"
                    width="30%">
                <el-form :model="form" label-width="120px">
                    <el-form-item label="Username">
                        <el-input v-model="form.username" style="width: 80%;"></el-input>
                    </el-form-item>
                    <el-form-item label="Nickname">
                        <el-input v-model="form.nickName" style="width: 80%;"></el-input>
                    </el-form-item>
                    <el-form-item label="Age">
                        <el-input v-model="form.age" style="width: 80%;"></el-input>
                    </el-form-item>
                    <el-form-item label="Sex">
                        <el-radio v-model="form.sex" label="male">Male</el-radio>
                        <el-radio v-model="form.sex" label="female">Female</el-radio>
                        <el-radio v-model="form.sex" label="unknow">Unknow</el-radio>
                    </el-form-item>
                    <el-form-item label="Address">
                        <el-input type="textarea" v-model="form.address" style="width: 80%;"></el-input>
                    </el-form-item>
                </el-form>
                <template #footer>
                    <span class="dialog-footer">
                      <el-button @click="dialogVisible = false">Cancel</el-button>
                      <el-button type="primary" @click="save">O K</el-button>
                    </span>
                </template>
            </el-dialog>
        </div>
    </div>
</template>

<script>

    import request from "@/utils/request";

    export default {
        data() {
            return {
                dialogVisible: false,
                form: {},
                search: '',
                currentPage: 1,
                pageSize: 10,
                total: 0,
                tableData: []
            }
        },
        created() {
            this.load()
        },
        methods: {
            load() {
                request.get("/api/user", {
                    params: {
                        pageNum: this.currentPage,
                        pageSize: this.pageSize,
                        search: this.search
                    }
                }).then(res => {
                    console.log(res)
                    this.tableData = res.data.records
                    this.total = res.data.total
                })
            },
            add() {
                this.dialogVisible = true
                this.form = {}
            },
            save() {
                if (this.form.id) { //update a employee
                    request.put("/api/user", this.form).then(res => {
                        console.log(res)
                        if (res.code === '0') {
                            this.$message({
                                type: "success",
                                message: "SUCCESS!"
                            })
                        } else {
                            this.$message({
                                type: "error",
                                message: res.msg
                            })
                        }
                    })
                } else {    //new a employee
                    request.post("/api/user", this.form).then(res => {
                        console.log(res)
                        if (res.code === '0') {
                            this.$message({
                                type: "success",
                                message: "SUCCESS!"
                            })
                        } else {
                            this.$message({
                                type: "error",
                                message: res.msg
                            })
                        }
                    })
                }
                this.load()
                this.dialogVisible = false
            },
            handleEdit(row) {
                this.form = JSON.parse(JSON.stringify(row))
                this.dialogVisible = true
            },
            handleSizeChange(pageSize) {
                this.pageSize = pageSize
                this.load()
            },
            handleCurrentChange(pageNum) {
                this.currentPage = pageNum
                this.load()
            },
            handleDelete(id) {
                console.log(id)
                request.delete("/api/user/" + id).then(res => {
                    if (res.code === '0') {
                        this.$message({
                            type: "success",
                            message: "SUCCESS!"
                        })
                    } else {
                        this.$message({
                            type: "error",
                            message: res.msg
                        })
                    }
                })
                this.load();
            }
        }
    }
</script>