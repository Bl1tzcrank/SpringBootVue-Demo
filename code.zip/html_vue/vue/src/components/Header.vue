<template>
    <div style="height: 50px; line-height: 50px; border-bottom: 1px solid #ccc; display: flex">
        <div style="width: 200px; padding-left: 30px; font-weight: bold; color: dodgerblue;">{{user.username}} 's
            System
        </div>
        <div style="flex: 1"></div>
        <div style="width: 100px">
            <el-dropdown :hide-on-click="false">
          <span class="el-dropdown-link">
            {{user.username}}<i class="el-icon-arrow-down el-icon--right"></i>
          </span>
                <template #dropdown>
                    <el-dropdown-menu>
                        <!--<el-dropdown-item>Information</el-dropdown-item>-->
                        <!--<el-dropdown-item>Help</el-dropdown-item>-->
                        <!--<el-dropdown-item divided>Configuration</el-dropdown-item>-->
                        <el-dropdown-item @click="$router.push('/login')">Exit</el-dropdown-item>
                    </el-dropdown-menu>
                </template>
            </el-dropdown>
        </div>
    </div>
</template>

<script>
    export default {
        name: "Header",
        data() {
            return {
                user: {},
                path: this.$route.path
            }
        },
        created() {
            let userStr = sessionStorage.getItem("user") || "{}"
            this.user = JSON.parse(userStr)
            console.log(userStr)

        }
    }
</script>