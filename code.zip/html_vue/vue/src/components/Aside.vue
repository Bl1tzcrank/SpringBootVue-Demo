<template>
    <div>
        <el-menu
                style="width: 200px; min-height: calc(100vh - 50px)"
                router
                default-active="index"
                class="el-menu-vertical-demo"
                background-color="#545c64"
                text-color="#fff"
                active-text-color="#ffd04b">
            <el-submenu index="1" v-if="user.role === 1">
                <template #title>
                    <i class="el-icon-location"></i>
                    <span>Admin</span>
                </template>
                <el-menu-item-group>
                    <el-menu-item index="user">User INFO</el-menu-item>
                </el-menu-item-group>
            </el-submenu>
            <el-submenu index="2">
                <template #title>
                    <i class="el-icon-location"></i>
                    <span>INFO</span>
                </template>
                <el-menu-item-group>
                    <el-menu-item index="index">Welcome</el-menu-item>
                </el-menu-item-group>
                <el-menu-item-group>
                    <el-menu-item index="book">Book INFO</el-menu-item>
                </el-menu-item-group>
            </el-submenu>
        </el-menu>
    </div>
</template>
<script>
    // import request from "@/utils/request";

    export default {
        name: "Aside",
        data() {
            return {
                user: {},
                path: this.$route.path
            }
        },
        created() {
            let userStr = sessionStorage.getItem("user") || "{}"
            this.user = JSON.parse(userStr)
            console.log(userStr)
            // request.get("/api/user/" + this.user.id).then(res => {
            //     if (res.code === '0') {
            //         this.user = res.data
            //     }
            // })
        }
    }
</script>
<style scoped>

</style>
<!--router in el-menu-->