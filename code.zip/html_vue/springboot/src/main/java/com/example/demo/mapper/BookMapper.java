package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.Book;

public interface BookMapper extends BaseMapper <Book>
{
}
